import React from 'react';
import { ShoppingCart, Star, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';

export default function ProductCard({ product }) {
  const navigate = useNavigate();
  const { addToCart } = useCart();

  const handleAdd = (e) => {
    e.stopPropagation(); // Prevents clicking the card to navigate
    addToCart(product);
  };

  return (
    <div style={styles.card} onClick={() => navigate(`/shop/${product.id}`)}>
      {/* Image Section */}
      <div style={styles.imageContainer}>
        <img src={product.image_url} alt={product.name} style={styles.img} />
        <button style={styles.wishlistBtn} onClick={(e) => e.stopPropagation()}>
          <Heart size={16} color="#888" />
        </button>
      </div>

      {/* Info Section */}
      <div style={styles.info}>
        <div style={styles.metaRow}>
          <span style={styles.category}>{product.category}</span>
          <div style={styles.rating}>
            <Star size={12} fill="#FFB800" color="#FFB800" />
            <span style={{ marginLeft: '4px' }}>{product.rating || "4.8"}</span>
          </div>
        </div>

        <h3 style={styles.name}>{product.name}</h3>

        <div style={styles.priceRow}>
          <div>
            <span style={styles.price}>${product.price?.toFixed(2)}</span>
          </div>
          <button style={styles.cartBtn} onClick={handleAdd}>
            <ShoppingCart size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  card: { backgroundColor: '#fff', borderRadius: '28px', padding: '12px', cursor: 'pointer', transition: 'transform 0.2s ease', boxShadow: '0 4px 15px rgba(0,0,0,0.02)', display: 'flex', flexDirection: 'column' },
  imageContainer: { width: '100%', aspectRatio: '1/1', borderRadius: '20px', overflow: 'hidden', backgroundColor: '#f8f8f8', marginBottom: '12px', position: 'relative' },
  img: { width: '100%', height: '100%', objectFit: 'cover' },
  wishlistBtn: { position: 'absolute', top: '10px', right: '10px', backgroundColor: '#fff', border: 'none', width: '32px', height: '32px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' },
  info: { padding: '0 4px' },
  metaRow: { display: 'flex', justifyContent: 'space-between', marginBottom: '8px' },
  category: { fontSize: '11px', color: '#aaa', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.5px' },
  rating: { fontSize: '12px', fontWeight: '800', display: 'flex', alignItems: 'center' },
  name: { fontSize: '16px', fontWeight: '700', marginBottom: '12px', color: '#121212', height: '40px', overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' },
  priceRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto' },
  price: { fontSize: '18px', fontWeight: '900', color: '#000' },
  cartBtn: { backgroundColor: '#121212', color: '#fff', border: 'none', width: '40px', height: '40px', borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }
};